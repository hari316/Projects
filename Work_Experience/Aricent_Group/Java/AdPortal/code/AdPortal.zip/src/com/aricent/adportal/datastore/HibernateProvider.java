package com.aricent.adportal.datastore;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Example;
import org.hibernate.criterion.Restrictions;
import org.hibernate.mapping.Array;
import org.json.JSONObject;

import com.aricent.adportal.datastore.hbn.Adlets;
import com.aricent.adportal.datastore.hbn.Advertisements;
import com.aricent.adportal.datastore.hbn.Users;
import com.aricent.adportal.utils.AdPortalUtils;

public class HibernateProvider implements DataStore{
	
	public List<Users> ValidateUser(Users user) {
		// TODO Auto-generated method stub
		AdPortalUtils util = new AdPortalUtils();
		SessionFactory sessionFactory = util.getSessionFactory();
		Session session=null;
		Transaction transaction=null;
		List<Users> userList = null;
		try
		{
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			Criteria cr = session.createCriteria(Users.class);
			System.out.println("UserName: "+ user.getUserId());
			System.out.println("UserPwd: "+ user.getPassword());
            cr.add(Restrictions.eq("userId", user.getUserId()));
            cr.add(Restrictions.eq("password", user.getPassword()));
            userList = cr.list();
			//userList = session.createCriteria(Users.class).add(Example.create(user)).list(); //Users.class
			transaction.commit();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally{
			if (null != session){
				session.close();
			}
		}
		return userList;
	}

	public List<Users> CheckUser(Users user) {
		// TODO Auto-generated method stub
		AdPortalUtils util = new AdPortalUtils();
		SessionFactory sessionFactory = util.getSessionFactory();
		Session session=null;
		Transaction transaction=null;
		List<Users> userList = null;
		try
		{
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			userList = session.createCriteria(Users.class).add(Example.create(user)).list(); //Users.class
			transaction.commit();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally{
			if (null != session){
				session.close();
			}
		}
		return userList;
	}


	public boolean createNewUser(Users obj) {
		// TODO Auto-generated method stub
		AdPortalUtils util = new AdPortalUtils();
		SessionFactory sessionFactory = util.getSessionFactory();
		Session session=null;
        Transaction transaction=null;
        try
        {
               //load .cfg.xml file
               session = sessionFactory.openSession();
               transaction = session.beginTransaction();
               session.save(obj);
               transaction.commit();
        }
        catch (Exception e) {
               e.printStackTrace();
               return false;
        }
        finally{
			if (null != session){
				session.close();
			}
		}
        return true;

	}

	/*public List<Users> checkAvailableUser(Users user) {
		// TODO Auto-generated method stub
		SessionFactory sf=null;
		Session session=null;
		Transaction transaction=null;
		List<Users> userList = null;
		try
		{
			//load .cfg.xml file
			Configuration config = new Configuration();
			config.configure();
			ServiceRegistry serviceRegistry = new ServiceRegistryBuilder().applySettings(config.getProperties()).buildServiceRegistry();
			sf = config.buildSessionFactory(serviceRegistry);
			session = sf.openSession();
			transaction = session.beginTransaction();
			userList = session.createCriteria("com.aricent.adportal.datastore.hbn.Users").add(Example.create(user)).list(); //Users.class
			transaction.commit();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return userList;
		
	}*/
	public List<Advertisements> getAdvertisements(String userId) {
		List<Advertisements> result = new ArrayList<Advertisements>();
		AdPortalUtils util = new AdPortalUtils();
		SessionFactory sessionFactory = util.getSessionFactory();
        Session session = sessionFactory.getCurrentSession()
                    .getSessionFactory().openSession();
        Transaction tx = null;
        
        try {
            tx = session.beginTransaction();
            Criteria cr = session.createCriteria(Advertisements.class);
            cr.add(Restrictions.eq("adv_user_id", userId));
            result = cr.list();
            tx.commit();
      } catch (Exception e) {
    	  	e.printStackTrace();
            return null;
      } finally {
            session.close();
      }
        
		return result;
	}
	
	public List<Advertisements> getUsersAdvertisements(String userId) {
		System.out.println("hibernate function");
		List<Advertisements> result = new ArrayList<Advertisements>();
		AdPortalUtils util = new AdPortalUtils();
		SessionFactory sessionFactory = util.getSessionFactory();
        Session session = sessionFactory.getCurrentSession()
                    .getSessionFactory().openSession();
        Transaction tx = null;
        
        try {
            tx = session.beginTransaction();
            Criteria cr = session.createCriteria(Advertisements.class);
            cr.add(Restrictions.eq("users.userId", userId));
            result = cr.list();
            tx.commit();
      } catch (Exception e) {
    	  	e.printStackTrace();
            return null;
      } finally {
            session.close();
      }
        
		return result;
	}
	
	public Advertisements readData(String adv_id) {
		// TODO Auto-generated method stub
		AdPortalUtils util = new AdPortalUtils();
		SessionFactory sessionFactory = util.getSessionFactory();
		Session session=null;
        Transaction transaction=null;
        List<Adlets> adletList = null;
        Advertisements Admain = null;
        try
        {               
               session = sessionFactory.openSession();
               transaction = session.beginTransaction();
               Criteria cr = session.createCriteria(Advertisements.class);
               cr.add(Restrictions.eq("advId", adv_id));
               Admain = new Advertisements();
               Admain = (Advertisements)cr.uniqueResult();        
               transaction.commit();         
        }
        catch (Exception e) {
               e.printStackTrace();
               return null;
        }finally{
			if (null != session){
				session.close();
			}
		}
        return Admain;
	}
		
	public boolean updateAdvertisements(Advertisements adv_obj) {
		AdPortalUtils util = new AdPortalUtils();
		SessionFactory sessionFactory = util.getSessionFactory();
		Session session=null;
        Transaction transaction=null;
        
        try
        {
               //load .cfg.xml file
               session = sessionFactory.openSession();
               transaction = session.beginTransaction(); 
               session.saveOrUpdate(adv_obj);
               transaction.commit();
        }
        catch (Exception e) {
               e.printStackTrace();
               return false;
        }
        finally{
			if (null != session){
				session.close();
				
			}
		}
        return true;
	}
	
	public boolean createAdvertisements(Advertisements adv_obj) {
		// TODO Auto-generated method stub
		AdPortalUtils util = new AdPortalUtils();
		SessionFactory sessionFactory = util.getSessionFactory();
		Session session=null;
        Transaction transaction=null;
        
        try
        {
               //load .cfg.xml file
               session = sessionFactory.openSession();
               transaction = session.beginTransaction();

               Advertisements Admain = (Advertisements)session.get(Advertisements.class,adv_obj.getAdvId());
               if(Admain != null) {
            	   System.out.println("Delete Existing Advertisement Object ...");
            	   Set<Adlets> adletSet = Admain.getAdletses();
            	   for(Adlets a:adletSet) {
            		   System.out.println("Adlet object deleted ... "+a.getAdlId());
            		   session.delete(a);
            	   }
            	   session.delete(Admain);
            	   //Admain.setAdletses(adv_obj.getAdletses()); 
               }
               Admain = adv_obj;
               session.save(Admain);
               transaction.commit();
        }
        catch (Exception e) {
               e.printStackTrace();
               return false;
        }
        finally{
			if (null != session){
				session.close();
				
			}
		}
        return true;
	}
	
	public boolean adAdlets(Set<Adlets> adletSet) {
		// TODO Auto-generated method stub
		AdPortalUtils util = new AdPortalUtils();
		SessionFactory sessionFactory = util.getSessionFactory();
        Session session = sessionFactory.getCurrentSession()
                    .getSessionFactory().openSession();
        Transaction tx = null;
        try {
              tx = session.beginTransaction();
              for (Adlets adlet : adletSet) {
            	    System.out.println("Adlet ADID: .... "+adlet.getAdvertisements().getAdvId());
            	    //session.merge(adlet);
                    session.saveOrUpdate(adlet);
              }
              tx.commit();
        } catch (Exception e) {
              if (tx != null)
                    tx.rollback();
              return false;
        } finally {
              session.close();
        }
        return true;
	}
	
	public List<Advertisements> getAdvertisements()
	{	
		Transaction transaction=null;
		List<Advertisements> adminList = null;
		try
		{
			AdPortalUtils util = new AdPortalUtils();
			SessionFactory sessionFactory = util.getSessionFactory();
	        Session session = sessionFactory.getCurrentSession()
	                    .getSessionFactory().openSession();
			transaction = session.beginTransaction();
			adminList = session.createCriteria(Advertisements.class).add(Example.create(new Advertisements())).list(); //Users.class
			transaction.commit();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return adminList;
	}
	
}
