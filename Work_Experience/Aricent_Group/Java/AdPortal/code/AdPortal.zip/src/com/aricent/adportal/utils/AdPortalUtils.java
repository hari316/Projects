package com.aricent.adportal.utils;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

/**
 * Description: This class contains common methods
 * 
 * @author BGH29309
 *
 */
public class AdPortalUtils {
	
	public static boolean isNullOrEmpty(String input){
		return null == input?true:input.trim().length() > 0 ?false:true;
	}

	public static String readPropertiesFile(String key)
	{
		String filePath = null;				
		try {
			
			 Properties prop = new Properties();
			 ClassLoader loader = Thread.currentThread().getContextClassLoader();           
			 InputStream stream = loader.getResourceAsStream("props.properties");
			 prop.load(stream);
			 filePath = prop.getProperty(key);		 	 
			 return filePath;						 			 			 
			
		} catch (FileNotFoundException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		catch (IOException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		return null;
	}
	
	public SessionFactory getSessionFactory(){
		Configuration config = new Configuration();
		config.configure();
		ServiceRegistry serviceRegistry = new ServiceRegistryBuilder().applySettings(config.getProperties()).buildServiceRegistry();
		return config.buildSessionFactory(serviceRegistry);
	}
}
