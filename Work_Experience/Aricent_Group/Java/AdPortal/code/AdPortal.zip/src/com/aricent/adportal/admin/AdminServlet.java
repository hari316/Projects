package com.aricent.adportal.admin;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;

import com.aricent.adportal.datastore.hbn.Advertisements;
import com.aricent.adportal.service.ServiceProvider;

/**
 * Servlet implementation class AdminServlet
 */
public class AdminServlet extends HttpServlet {
	private static final long	serialVersionUID	= 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AdminServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		/**
		 * Description: This method gets all the advertisements from ORM and put
		 * into json object.
		 * 
		 * @return JSON Object
		 */

		System.out.println("Getting advertisements");
		ServiceProvider provider = new ServiceProvider();
		if ("validate".equals(request.getParameter("requestType"))) {
			System.out.println("Validate type:: ");
		}
		List<Advertisements> advList = provider.getAdvertisements();
		JSONArray jsonArray = new JSONArray();
		JSONObject obj = null;
		try {
			for (Advertisements adv : advList) {
				obj = new JSONObject();
				obj.put("id", adv.getAdvId());
				obj.put("title", adv.getAdvTitle());
				obj.put("status", adv.getAdvStatus());
				obj.put("createdate", adv.getAdvCreateDateTime());
				jsonArray.put(obj);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		response.getWriter().print(jsonArray.toString());

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
