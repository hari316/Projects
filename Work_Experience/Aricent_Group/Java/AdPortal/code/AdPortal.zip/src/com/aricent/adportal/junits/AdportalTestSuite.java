package com.aricent.adportal.junits;

import junit.framework.Test;
import junit.framework.TestSuite;

public class AdportalTestSuite {

	/**
	 * @param args
	 */
	public static Test testSuite() {
		TestSuite suite = new TestSuite("All Test Cases");
		suite.addTest(new TestSuite(ServiceProviderTest.class));
		return suite;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		junit.textui.TestRunner.run(testSuite());
	}

}
