package com.aricent.adportal.displayAds;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONObject;

import com.aricent.adportal.datastore.DataStore;
import com.aricent.adportal.datastore.DataStoreFactory;
import com.aricent.adportal.datastore.hbn.Adlets;
import com.aricent.adportal.datastore.hbn.Advertisements;
import com.aricent.adportal.utils.AdPortalUtils;

/**
 * Servlet implementation class AdServlet
 */
public class PreviewAdServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public PreviewAdServlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String adId = request.getParameter("adId");
		String index= request.getParameter("index");
		String flag= request.getParameter("flagkey");
		
		if(AdPortalUtils.isNullOrEmpty(adId)){
			adId="AD3829";
		}
		
		Advertisements admain=null;
		List<Adlets> temp=null;
		admain = (Advertisements)getServletContext().getAttribute(request.getParameter("adId"));
		temp = new ArrayList<Adlets>(admain.getAdletses());
				
		int count=0;
		int total=0;
		int ind= Integer.parseInt(index);
		
		total = temp.size();

		for (Adlets a : temp){
			if(count == ind)
			{					
				JSONObject obj = new JSONObject();
				//System.out.println("Image URL: "+a.getUrl());
				try{
					obj.put("userId", admain.getUsers().getUserId());
					obj.put("advId", admain.getAdvId());
					obj.put("advTitle", admain.getAdvTitle());
					obj.put("title", a.getAdlTitle());
					obj.put("url", a.getUrl());
					obj.put("adletId", a.getAdlId());
					obj.put("sizeX", a.getSizex());
					obj.put("sizeY", a.getSizey());
					obj.put("timeOut", a.getTimeout());
					obj.put("type", a.getAdlType());
					obj.put("displayPath", request.getContextPath());
					
					if(a.getAdlType().startsWith("image/"))
					{
						obj.put("tagType", "img");
					}
					else if(a.getAdlType().startsWith("video/"))
					{
						obj.put("tagType", "video");
					}
					else
					{
						obj.put("tagType", "other");
					}
							
					if( (count+1) == total )
					{
						obj.put("hasMore", "No");
					}
					else
					{
						obj.put("hasMore", "Yes");
					}			
				}
				catch(Exception ex){
					ex.printStackTrace();
				}
				response.getWriter().write(obj.toString());						
			}		
			count++;		
		}
				
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
	}

}
