package com.aricent.adportal.datastore.hbn;

// Generated 21 Mar, 2013 5:23:23 PM by Hibernate Tools 3.4.0.CR1

import java.util.List;
import javax.naming.InitialContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.LockMode;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Example;

/**
 * Home object for domain model class Adlets.
 * @see com.aricent.adportal.hbn.Adlets
 * @author Hibernate Tools
 */
public class AdletsHome {

	private static final Log log = LogFactory.getLog(AdletsHome.class);

	private final SessionFactory sessionFactory = getSessionFactory();

	protected SessionFactory getSessionFactory() {
		try {
			return (SessionFactory) new InitialContext()
					.lookup("SessionFactory");
		} catch (Exception e) {
			log.error("Could not locate SessionFactory in JNDI", e);
			throw new IllegalStateException(
					"Could not locate SessionFactory in JNDI");
		}
	}

	public void persist(Adlets transientInstance) {
		log.debug("persisting Adlets instance");
		try {
			sessionFactory.getCurrentSession().persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}
	}

	public void attachDirty(Adlets instance) {
		log.debug("attaching dirty Adlets instance");
		try {
			sessionFactory.getCurrentSession().saveOrUpdate(instance);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public void attachClean(Adlets instance) {
		log.debug("attaching clean Adlets instance");
		try {
			sessionFactory.getCurrentSession().lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public void delete(Adlets persistentInstance) {
		log.debug("deleting Adlets instance");
		try {
			sessionFactory.getCurrentSession().delete(persistentInstance);
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw re;
		}
	}

	public Adlets merge(Adlets detachedInstance) {
		log.debug("merging Adlets instance");
		try {
			Adlets result = (Adlets) sessionFactory.getCurrentSession().merge(
					detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public Adlets findById(java.lang.String id) {
		log.debug("getting Adlets instance with id: " + id);
		try {
			Adlets instance = (Adlets) sessionFactory.getCurrentSession().get(
					"com.aricent.adportal.hbn.Adlets", id);
			if (instance == null) {
				log.debug("get successful, no instance found");
			} else {
				log.debug("get successful, instance found");
			}
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}

	public List findByExample(Adlets instance) {
		log.debug("finding Adlets instance by example");
		try {
			List results = sessionFactory.getCurrentSession()
					.createCriteria("com.aricent.adportal.hbn.Adlets")
					.add(Example.create(instance)).list();
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw re;
		}
	}
}
