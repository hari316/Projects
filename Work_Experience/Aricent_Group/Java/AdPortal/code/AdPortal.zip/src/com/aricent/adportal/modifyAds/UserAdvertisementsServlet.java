package com.aricent.adportal.modifyAds;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;

import com.aricent.adportal.datastore.hbn.Advertisements;
import com.aricent.adportal.service.ServiceProvider;

/**
 * Servlet implementation class UserAdvertisements
 */
public class UserAdvertisementsServlet extends HttpServlet {
	private static final long	serialVersionUID	= 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UserAdvertisementsServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		/**
		 * Description: This method get the details of all the advertisements of
		 * a particular user
		 * 
		 * @return JSON Objects
		 */

		System.out.println("users servlet");
		String userId = request.getParameter("userId");
		System.out.println("user: " + userId);
		ServiceProvider provider = new ServiceProvider();
		List<Advertisements> advList = provider.getUserAdvertisements(userId);
		JSONArray jsonArray = new JSONArray();
		JSONObject obj = null;
		try {
			for (Advertisements adv : advList) {
				obj = new JSONObject();
				obj.put("id", adv.getAdvId());
				obj.put("title", adv.getAdvTitle());
				obj.put("status", adv.getAdvStatus());
				jsonArray.put(obj);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		response.getWriter().print(jsonArray.toString());

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
