package com.aricent.adportal.admin;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import com.aricent.adportal.datastore.hbn.Advertisements;
import com.aricent.adportal.service.ServiceProvider;

/**
 * Servlet implementation class UpdateAdvertisement
 */
public class UpdateAdvertisement extends HttpServlet {
	private static final long	serialVersionUID	= 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UpdateAdvertisement() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		/**
		 * Description: This method get the update on status of advertisement
		 * whether it is approved or reject by admin.
		 * 
		 * @return JSON Object
		 */
		String advId = request.getParameter("adId");
		String operationType = request.getParameter("operationType");

		Advertisements adv = (Advertisements) getServletContext().getAttribute("previewAdvertisement");
		adv.setAdvStatus(operationType);
		ServiceProvider provider = new ServiceProvider();
		boolean status = provider.updateAdvertisementsStatus(adv);

		JSONObject obj = new JSONObject();
		try {
			obj.put("status", status);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		response.getWriter().print(obj.toString());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
