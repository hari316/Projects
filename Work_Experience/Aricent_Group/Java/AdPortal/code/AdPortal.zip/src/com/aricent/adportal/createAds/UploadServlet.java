package com.aricent.adportal.createAds;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.FileUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.aricent.adportal.datastore.hbn.Adlets;
import com.aricent.adportal.datastore.hbn.Advertisements;
import com.aricent.adportal.datastore.hbn.Users;
import com.aricent.adportal.jaxb.SCJAXBParser;
import com.aricent.adportal.jaxb.impl.AdvertisementImpl;
import com.aricent.adportal.jaxb.impl.AdvertisementTypeImpl.AdletTypeImpl;

/**
 * Servlet implementation class SaveAdDetail
 */
public class UploadServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String filePath = null;

	public UploadServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	/*
	 * public void init(ServletConfig config) throws ServletException { // TODO
	 * Auto-generated method stub super.init(config); ServletContext context =
	 * getServletContext(); filePath = context.getInitParameter("fileUpload");
	 * 
	 * }
	 */
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("Servlet: doGet Method called ...");

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@SuppressWarnings("unchecked")
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("Upload Servlet doPost Method called ...");
		List<FileItem> items;
		int counter = 1000;

		HttpSession session = request.getSession();
		String userId = session.getAttribute("userId").toString();
		//String userId = "29309";
		JSONObject Adobj = new JSONObject();

		try {

			/*---------------- Uploading File ---------------*/
			String fileName = "";
			ServletFileUpload servletFileUpload = new ServletFileUpload(
					new DiskFileItemFactory());
			items = servletFileUpload.parseRequest(request);
			for (FileItem item : items) {

				if (!item.isFormField()) {
					// <input type="file">
					fileName = item.getName();
					// System.out.println("Field name: " + item.getFieldName());
					try {
						String[] fup = fileName.split("\\.");
						System.out.println("Input FileName: "+fup[0]);
						System.out.println("Expected FileName: "+userId);
						//if (userId != fup[0]) {
						if (!userId.equalsIgnoreCase(fup[0])) {
							Adobj.put("status", 0);
							Adobj.put("error","Invalid file name: Please set Name as User ID ....");
							System.out.println("JSON OBJECTS"
									+ Adobj.toString());
							response.getWriter().write(Adobj.toString());
							return;
						}else {
							System.out.println("Valid Input FileName ....");
						}
						
					} catch (JSONException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					// System.out.println("File size: " + item.getSize());
					// System.out.println("File type: " +
					// item.getContentType());
				}

				
				Properties prop = new Properties();
				ClassLoader loader = Thread.currentThread().getContextClassLoader();
				InputStream stream = loader.getResourceAsStream("props.properties");
				prop.load(stream);
				String file_loc = prop.getProperty("uploadAdv_Loc")+userId+"/";

				
				File fileUploadLoc = new File(getServletContext().getRealPath(file_loc));
				
				System.out.println("Zip File Upload Directory: "+fileUploadLoc.getPath());
				
				if(!fileUploadLoc.exists()) {
					fileUploadLoc.mkdirs();
				}
				
				File file = new File(fileUploadLoc.getPath() + '\\' + item.getName());
				System.out.println("Temporary Uploading File Path: " + file.getPath());
				item.write(file);

				/*---------------- Unzipping file ---------------*/

				ZipFile zipFile = new ZipFile(file);
				Enumeration<?> enu = zipFile.entries();

				while (enu.hasMoreElements()) {
					ZipEntry zipEntry = (ZipEntry) enu.nextElement();

					String name = zipEntry.getName();
					long size = zipEntry.getSize();
					long compressedSize = zipEntry.getCompressedSize();
					System.out.printf(
							"name: %-20s | size: %6d | compressed size: %6d\n",
							name, size, compressedSize);

					File unzipFile = new File(getServletContext().getRealPath(file_loc + '\\' + name));

					if (name.endsWith("/")) {
						unzipFile.mkdirs();
						continue;
					}

					File parent = unzipFile.getParentFile();
					if (parent != null) {
						parent.mkdirs();
					}

					InputStream is = zipFile.getInputStream(zipEntry);
					FileOutputStream fos = new FileOutputStream(unzipFile);
					byte[] bytes = new byte[1024];
					int length;
					while ((length = is.read(bytes)) >= 0) {
						fos.write(bytes, 0, length);
					}
					is.close();
					fos.close();

				}
				zipFile.close();
				//item.delete();


				String filePath = file_loc + userId;
				File xFilepath = new File(filePath + "/xml");
				File xmlFile = new File(getServletContext().getRealPath(xFilepath + "/" + userId + ".xml"));

				Reader reader = new FileReader(xmlFile);
				SCJAXBParser jaxbParser = new SCJAXBParser();
				AdvertisementImpl aObj = new AdvertisementImpl();
				aObj = (AdvertisementImpl) jaxbParser
						.unmarshalFromReader(reader);

				String adId = "AD_" + (int) (Math.random() * 9999) + "_"
						+ aObj.getTitleAdv().substring(0, 3);
				adId = adId.replaceAll(" ", "");
				
				//File oldFile = new File(getServletContext().getRealPath(file_loc+userId));
		        // File (or directory) with new name
		        //File newFile = new File(getServletContext().getRealPath(file_loc+adId));
		        //oldFile.renameTo(newFile);
		        
				String adTitle = aObj.getTitleAdv();
				Date date = new Date();
				Users user = new Users();
				user.setUserId(userId);
				Advertisements adObj = new Advertisements(adId, user, "added",
						adTitle, date.toString());

				List<Adlets> temp = new ArrayList<Adlets>(aObj.getAdlet());
				List<Adlets> adletList = new ArrayList<Adlets>();

				Adlets a;

				for (int i = 0; i < aObj.getAdlet().size(); i++) {
					a = new Adlets();
					AdletTypeImpl x = (AdletTypeImpl) aObj.getAdlet().get(i);
					a.setAdlId(adId + counter++);
					a.setAdlTitle(x.getTitle());
					a.setUrl(x.getUrl());
					a.setAdlType(x.getType());
					a.setSizex(Integer.parseInt(x.getSizeX()));
					a.setSizey(Integer.parseInt(x.getSizeY()));
					a.setTimeout(Integer.parseInt(x.getTimeout()));
					a.setAdvertisements(adObj);
					System.out.println("Adlets Title: " + a.getAdlTitle());
					adletList.add(a);
				}
				// adObj.setAdletses(adletSet);
				Set<Adlets> adletSet = new HashSet<Adlets>(adletList);
				adObj.setAdletses(adletSet);

				System.out.println(adObj);
				System.out
						.println("Advertisement details Uploaded successfully ....");

				getServletContext().setAttribute(adId, adObj);
				getServletContext().setAttribute("uploadAdId", adId);

				/*********************** OBJECT SERIALIZATION *****************************/

				try {

					Adobj.put("status", 1);
					Adobj.put("advId", adObj.getAdvId());
					Adobj.put("adTitle", adObj.getAdvTitle());

					// adlets = new ArrayList<Adlets>(adObj.getAdletses());

					int adletSize = adletList.size();

					Adobj.put("adletSize", adletSize);

					JSONArray objArray = new JSONArray();
					JSONObject obj;
					for (int i = 0; i < adletSize; i++) {
						obj = new JSONObject();
						adletList.get(i).setAdlId(
								adletList.get(i).getAdlId()
										.replace(adObj.getAdvId(), ""));
						obj.put("adletId", adletList.get(i).getAdlId());
						obj.put("adletTitle", adletList.get(i).getAdlTitle());
						obj.put("adletUrl", adletList.get(i).getUrl());
						obj.put("adletType", adletList.get(i).getAdlType());
						obj.put("adletSX", adletList.get(i).getSizex());
						obj.put("adletSY", adletList.get(i).getSizey());
						obj.put("adletTimeout", adletList.get(i).getTimeout());
						objArray.put(obj);
					}

					Adobj.put("adlets", objArray);

				} catch (JSONException e) {
					// TODO Auto-generated catch block
					Adobj.put("status", 2);
					Adobj.put("error", e.toString());
					e.printStackTrace();
				}

				System.out.println("JSON OBJECTS" + Adobj.toString());
				response.getWriter().write(Adobj.toString());
				// response.sendRedirect("PreviewAd.jsp?adId="+
				// adObj.getAdvId());
			}

		} catch (FileUploadException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
