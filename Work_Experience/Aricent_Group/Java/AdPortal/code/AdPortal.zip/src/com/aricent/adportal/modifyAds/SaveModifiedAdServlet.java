package com.aricent.adportal.modifyAds;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.json.JSONObject;

import com.aricent.adportal.datastore.hbn.Adlets;
import com.aricent.adportal.datastore.hbn.Advertisements;
import com.aricent.adportal.datastore.hbn.Users;
import com.aricent.adportal.service.ServiceProvider;

/**
 * Servlet implementation class SaveModifiedAdServlet
 */
public class SaveModifiedAdServlet extends HttpServlet {
	private static final long	serialVersionUID	= 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public SaveModifiedAdServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		/**
		 * Description: This method get the details of the particular advertisement id from the context and change the status to submitted
		 * 
		 * @return JSON Object
		 */
		
		System.out.println("Save Modified Ad Servlet ::: doGet Method called ...");
		System.out.println("Adv ID : " + request.getParameter("adId"));
		// DataStore saveAdobj = DataStoreFactory.getHiber();
		Advertisements adv = (Advertisements) getServletContext().getAttribute(request.getParameter("adId"));
		adv.setAdvStatus("submitted");
		// boolean status = saveAdobj.createAdvertisements(adv);
		ServiceProvider provider = new ServiceProvider();
		provider.storeAdvertisement(adv);
		// System.out.println(admain.getAd_list().size());
		boolean status = provider.storeAdlets(adv.getAdletses());

		JSONObject obj = new JSONObject();
		try {
			obj.put("isSuccess", status);
			response.getWriter().write(obj.toString());
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		/**
		 * Description: This method get the modified details of the particular advertisement and store in the database
		 * 
		 * @return JSON Object
		 */
		
		System.out.println("Servlet doPost Method called ...");

		HttpSession session = request.getSession();
		String userId = session.getAttribute("userId").toString();

		File filePath;

		List<FileItem> items;
		Advertisements adObj = null;
		List<Adlets> adlets = new ArrayList<Adlets>();
		String adId = null;
		String adTitle = null;
		String status = "ADDED";
		Adlets adletObj = new Adlets();
		int counter = 1000;

		Properties prop = new Properties();
		ClassLoader loader = Thread.currentThread().getContextClassLoader();
		InputStream stream = loader.getResourceAsStream("props.properties");
		prop.load(stream);
		String file_loc = prop.getProperty("uploadAdv_Loc") + userId;

		try {
			ServletFileUpload servletFileUpload = new ServletFileUpload(new DiskFileItemFactory());
			items = servletFileUpload.parseRequest(request);
			for (FileItem item : items) {

				if (!item.isFormField()) {
					// <input type="file">
					System.out.println("img Field name: " + item.getFieldName());
					System.out.println("File name: " + item.getName());
					System.out.println("File size: " + item.getSize());
					System.out.println("File type: " + item.getContentType());
					if (item.getContentType().startsWith("image/")) {
						filePath = new File(getServletContext().getRealPath(file_loc + "/" + adId + "/images"));
					} else if (item.getContentType().startsWith("video/")) {
						filePath = new File(getServletContext().getRealPath(file_loc + "/" + adId + "/videos"));
					} else {
						filePath = new File(getServletContext().getRealPath(file_loc + "/" + adId + "/otherFiles"));
					}
					if (item.getFieldName().equals("url")) {
						adletObj.setUrl(item.getName());
						adletObj.setAdlType(item.getContentType());

						System.out.println("File Upload Directory: " + filePath.getPath());

						if (!filePath.exists()) {
							filePath.mkdirs();
						}
						File file = new File(filePath.getPath() + '\\' + item.getName());

						System.out.println("Image/Video file Path: " + filePath);
						item.write(file);
					}
				} else {

					// <input type="text|submit|hidden|password|button">,
					// <select>, <textarea>, <button>
					if (item.getFieldName().equals("title")) {
						adTitle = item.getString();
						Date date = new Date();
						Users user = new Users();
						user.setUserId(userId);
						adObj = new Advertisements(adId, user, status, adTitle, date.toString());
					} else if (item.getFieldName().equals("advid")) {
						adId = item.getString();
						System.out.println("advertisement id in modified servlet : " + adId);
					} else if (item.getFieldName().equals("adletId")) {
						adletObj.setAdlId(item.getString());

					} else if (item.getFieldName().equals("adletTitle")) {
						adletObj.setAdlTitle(item.getString());
					} else if (item.getFieldName().equals("urlText")) {
						String urlName = item.getString();
						String[] istr = urlName.split(":");
						if (urlName.startsWith("image/")) {
							adletObj.setAdlType(istr[0]);
						} else if (urlName.startsWith("video/")) {
							adletObj.setAdlType(istr[0]);
						} else {
							adletObj.setAdlType("Others/");
						}
						adletObj.setUrl(istr[1]);
					} else if (item.getFieldName().equals("sizeX")) {
						adletObj.setSizex(Integer.parseInt(item.getString()));
					} else if (item.getFieldName().equals("sizeY")) {
						adletObj.setSizey(Integer.parseInt(item.getString()));
					} else if (item.getFieldName().equals("timeOut")) {
						adletObj.setTimeout(Integer.parseInt(item.getString()));
						// adletObj.setAdv_id(adId);
						adletObj.setAdlId(adId + counter++);
						adletObj.setAdvertisements(adObj);
						adlets.add(adletObj);
						adletObj = new Adlets();
					}

				}
			}
		} catch (FileUploadException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Set<Adlets> adletSet = new HashSet<Adlets>(adlets);
		adObj.setAdletses(adletSet);
		System.out.println(adObj);
		System.out.println("Advertisement details Updated successfully ....");
		getServletContext().setAttribute(adId, adObj);
		response.sendRedirect("PreviewAd.jsp?adId=" + adObj.getAdvId());
	}

}
