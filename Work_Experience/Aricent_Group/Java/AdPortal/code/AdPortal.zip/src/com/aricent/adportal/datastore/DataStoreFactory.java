package com.aricent.adportal.datastore;

public abstract class DataStoreFactory {

	public static DataStore getData()
	{
		//return new DataStoreProvider();
		return null;
	}
	
	public static DataStore getHiber()
	{
		return new HibernateProvider();
	}
}
