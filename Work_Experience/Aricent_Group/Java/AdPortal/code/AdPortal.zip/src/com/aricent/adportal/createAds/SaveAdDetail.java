package com.aricent.adportal.createAds;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.FileUtils;
import org.json.JSONObject;

import com.aricent.adportal.datastore.hbn.Adlets;
import com.aricent.adportal.datastore.hbn.Advertisements;
import com.aricent.adportal.datastore.hbn.Users;
import com.aricent.adportal.service.ServiceProvider;
import com.aricent.adportal.utils.AdPortalUtils;

/**
 * Servlet implementation class SaveAdDetail
 */
public class SaveAdDetail extends HttpServlet {
	private static final long	serialVersionUID	= 1L;

	// private String filePath =null;
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public SaveAdDetail() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 *      
	 * Description: This method updates advertisement details and loads images/videos from temporary location to file server.     
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("SaveAdDetails Servlet:::doGet Method called ...");

		String adId = request.getParameter("adId");
		
		System.out.println("Adv ID ::: " + adId);
		
		Advertisements adv = (Advertisements) getServletContext().getAttribute(adId);
		adv.setAdvStatus("submitted");
		String userId = adv.getUsers().getUserId();
		ServiceProvider provider = new ServiceProvider();
		provider.storeAdvertisement(adv);
		boolean status = provider.storeAdlets(adv.getAdletses());
		
		if (status) {
			System.out.println("Advertisements details saved in the database successfully ....");

			Properties prop = new Properties();
			ClassLoader loader = Thread.currentThread().getContextClassLoader();
			InputStream stream = loader.getResourceAsStream("props.properties");
			prop.load(stream);
			String file_loc = prop.getProperty("uploadAdv_Loc");
			// String filePath = file_loc + userId +"/"+ adId;
			StringBuilder filePath = new StringBuilder(file_loc).append(userId).append("/").append(adId);
			File iFilePath = new File(getServletContext().getRealPath(filePath.append("/images").toString()));
			File vFilePath = new File(getServletContext().getRealPath(filePath.append("/videos").toString()));
			// File imageDesPath = new
			// File(getServletContext().getRealPath("../Ads/"+userId+"/"+adId+"/images"));
			File imageDesPath = new File(getServletContext().getRealPath(
					new StringBuilder("../Ads/").append(userId).append("/").append(adId).append("/images").toString()));
			File videoDesPath = new File(getServletContext().getRealPath(
					new StringBuilder("../Ads/").append(userId).append("/").append(adId).append("/videos").toString()));

			if (!imageDesPath.exists()) {
				imageDesPath.mkdir();
			}

			if (!videoDesPath.exists()) {
				videoDesPath.mkdir();
			}

			if (iFilePath.exists()) {
				FileUtils.copyDirectory(iFilePath, imageDesPath);
			}

			if (vFilePath.exists()) {
				FileUtils.copyDirectory(vFilePath, videoDesPath);
			}

			System.out.println("Advertisements details(images and videos) moved to file server locations ....");
			
			// FileUtils.deleteDirectory(new
			// File(getServletContext().getRealPath(filePath)));
		}
		JSONObject obj = new JSONObject();
		try {
			obj.put("isSuccess", status);
			response.getWriter().write(obj.toString());
		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 *      
	 *  Description: This method saves advertisement details and loads images/videos to temporary file server location. 
	 */
	@SuppressWarnings("unchecked")
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("SaveAdDetails Servlet:::doPost Method called ...");

		HttpSession session = request.getSession();
		String userId = session.getAttribute("userId").toString();
		File filePath;

		List<FileItem> items;
		Advertisements adObj = null;
		List<Adlets> adlets = new ArrayList<Adlets>();
		String adId = null;
		String adTitle = null;
		String status = "ADDED";
		Adlets adletObj = new Adlets();
		int counter = 1000;
		
/*		Properties prop = new Properties();
		ClassLoader loader = Thread.currentThread().getContextClassLoader();
		InputStream stream = loader.getResourceAsStream("props.properties");
		prop.load(stream);
		StringBuilder file_loc = new StringBuilder(prop.getProperty("uploadAdv_Loc")).append(userId);*/
		
		StringBuilder file_loc = new StringBuilder(AdPortalUtils.readPropertiesFile("uploadAdv_Loc")).append(userId);
		StringBuilder Uploadfile_loc = new StringBuilder(file_loc);
		System.out.println("File Location: "+file_loc);
		try {
			ServletFileUpload servletFileUpload = new ServletFileUpload(new DiskFileItemFactory());
			items = servletFileUpload.parseRequest(request);
			for (FileItem item : items) {

				if (!item.isFormField()) {
					// <input type="file">
					System.out.println("img Field name: " + item.getFieldName());
					System.out.println("File name: " + item.getName());
					System.out.println("File size: " + item.getSize());
					System.out.println("File type: " + item.getContentType());
					if (item.getContentType().startsWith("image/")) {
						filePath = new File(getServletContext().getRealPath(file_loc.toString()+"/images"));
					} else if (item.getContentType().startsWith("video/")) {
						filePath = new File(getServletContext().getRealPath(file_loc.toString()+"/videos"));
					} else {
						filePath = new File(getServletContext().getRealPath(file_loc.toString()+"/otherFiles"));
					}
					if (item.getFieldName().equals("url")) {
						adletObj.setUrl(item.getName());
						adletObj.setAdlType(item.getContentType());

						System.out.println("File Upload Directory: " + filePath.getPath());

						if (!filePath.exists()) {
							filePath.mkdirs();
						}
						File file = new File( new StringBuilder(filePath.getPath()).append('\\').append(item.getName()).toString());
						item.write(file);
					}
				} else {
					// <input type="text|submit|hidden|password|button">,
					// <select>, <textarea>, <button>
					if (item.getFieldName().equals("title")) {
						adTitle = item.getString();

						adId = "AD_" + (int) (Math.random() * 9999) + "_" + adTitle.substring(0, 3);
						adId = adId.replaceAll(" ", "");

						file_loc.append("/").append(adId);
						File oldFile = new File(getServletContext().getRealPath(Uploadfile_loc.toString()+"/"+userId));
						System.out.println("Old File: "+oldFile.getPath());
						if (oldFile.exists()) {
							System.out.println("Renaming of upload directory from userId to Advertisement Id ...");
							File newFile = new File(getServletContext().getRealPath(Uploadfile_loc.toString()+"/"+adId));
							oldFile.renameTo(newFile);
							getServletContext().setAttribute("uploadAdId", adId);
						}
						Date date = new Date();
						Users user = new Users();
						user.setUserId(userId);
						adObj = new Advertisements(adId, user, status, adTitle, date.toString());
					} else if (item.getFieldName().equals("adletTitle")) {
						adletObj.setAdlTitle(item.getString());
					} else if (item.getFieldName().equals("urlText")) {
						String urlName = item.getString();
						String[] istr = urlName.split(":");
						if (urlName.startsWith("image/")) {
							adletObj.setAdlType(istr[0]);
						} else if (urlName.startsWith("video/")) {
							adletObj.setAdlType(istr[0]);
						} else {
							adletObj.setAdlType("Others/");
						}
						adletObj.setUrl(istr[1]);
						adId=getServletContext().getAttribute("uploadAdId").toString(); 

					} else if (item.getFieldName().equals("sizeX")) {
						adletObj.setSizex(Integer.parseInt(item.getString()));
					} else if (item.getFieldName().equals("sizeY")) {
						adletObj.setSizey(Integer.parseInt(item.getString()));
					} else if (item.getFieldName().equals("timeOut")) {
						adletObj.setTimeout(Integer.parseInt(item.getString()));
						adletObj.setAdlId(adId + counter++);
						adletObj.setAdvertisements(adObj);
						adlets.add(adletObj);
						adletObj = new Adlets();
					}

				}
			}
		} catch (FileUploadException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Set<Adlets> adletSet = new HashSet<Adlets>(adlets);
		adObj.setAdletses(adletSet);
		System.out.println(adObj);
		System.out.println("Advertisement details saved successfully ....");
		getServletContext().setAttribute(adId, adObj);
		response.sendRedirect("PreviewAd.jsp?adId=" + adId);
	}

}
