/*package com.aricent.adportal.datastore;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

import com.aricent.adportal.datastore.hbn.Adlets;
import com.aricent.adportal.datastore.hbn.Advertisements;
import com.aricent.adportal.datastore.hbn.Users;
import com.aricent.adportal.utils.AdPortalUtils;

public class DataStoreProvider extends DefaultHandler implements DataStore {
	
	private String _tempVal;
	private Adlets adlet;
	private List<Adlets> adlets = new ArrayList<Adlets>();
	private Advertisements searched_adv;
	
	public boolean createNewUser(Users obj) {
		// TODO Auto-generated method stub
		
		
		System.out.println("create new user");
		String insert = "insert into users(user_id,user_type,password,confirm_password,firstname,lastname,email_id,contact_number,address,state,country)"
				+ "values(?,?,?,?,?,?,?,?,?,?,?)";
	
		
		try {
			
			 reading the properties file 
			
			 Properties prop = new Properties();
			 ClassLoader loader =Thread.currentThread().getContextClassLoader();
			 InputStream stream =loader.getResourceAsStream("props.properties");
			 prop.load(stream);
			 String server = prop.getProperty("server");
			 connection with the mysql 
			 Connection conn = null;
			 String url = "jdbc:mysql://"+ server + ":3306/";
			 String dbName = prop.getProperty("database");
			 String driver = "com.mysql.jdbc.Driver";
			 String mysqluserName = prop.getProperty("username");
			 String mysqlpassword = prop.getProperty("password");

		Class.forName(driver).newInstance();
		conn = DriverManager.getConnection(url + dbName, mysqluserName,
				mysqlpassword);

		PreparedStatement ps = conn.prepareStatement(insert);
		ps.setString(1, obj.getUserId());
		ps.setString(2, obj.getUserType());
		ps.setString(3, obj.getPassword());
		ps.setString(4, obj.getConfirmPassword());
		//ps.setString(5, obj.getFirstName());
		//ps.setString(6, obj.getLastName());
		ps.setString(7, obj.getEmailId());
		//ps.setString(8, obj.getContactNo());
		ps.setString(9, obj.getAddress());
		ps.setString(10, obj.getState());
		ps.setString(11, obj.getCountry());

		ps.executeUpdate();
		ps.close();
		conn.close();
		return true;

	} catch (Exception ex) {
		Logger.getLogger(DataStoreProvider.class.getName()).log(Level.SEVERE, null, ex);
	}
	
	return false;
	}
	
	public boolean checkAvailableUser(String userid) {
		// TODO Auto-generated method stub

		
		
		try {
			
			 reading the properties file 
			
			 Properties prop = new Properties();
			 ClassLoader loader =Thread.currentThread().getContextClassLoader();
			 InputStream stream =loader.getResourceAsStream("props.properties");
			 prop.load(stream);
			 String server = prop.getProperty("server");
			 connection with the mysql 
			 Connection conn = null;
			 String url = "jdbc:mysql://"+ server + ":3306/";
			 String dbName = prop.getProperty("database");
			 String driver = "com.mysql.jdbc.Driver";
			 String mysqluserName = prop.getProperty("username");
			 String mysqlpassword = prop.getProperty("password");

			Statement st;
			Class.forName(driver).newInstance();
			conn = DriverManager.getConnection(url + dbName, mysqluserName,
					mysqlpassword);
			String query = "select * from users";
			st = conn.createStatement();
			ResultSet rs = st.executeQuery(query);
			String uid = null;

			while (rs.next()) {
				uid = rs.getString("user_id");

				if (uid.equals(userid)) {
					return true;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return false;
		
	}
	
	public List<Users> ValidateUser(Users user) {
		// TODO Auto-generated method stub
		
		Statement st;
		String usertype;
		int flag=0;
		try {
			
			 reading the properties file 		
			 Properties prop = new Properties();
			 ClassLoader loader =Thread.currentThread().getContextClassLoader();
			 InputStream stream =loader.getResourceAsStream("props.properties");
			 prop.load(stream);
			 String server = prop.getProperty("server");
			 connection with the mysql 
			 Connection conn = null;
			 String url = "jdbc:mysql://"+ server + ":3306/";
			 String dbName = prop.getProperty("database");
			 String driver = "com.mysql.jdbc.Driver";
			 String mysqluserName = prop.getProperty("username");
			 String mysqlpassword = prop.getProperty("password");
			 System.out.println("server : " + server);
			 System.out.println("database : " + dbName);
			 System.out.println("user name : " + mysqluserName);
			 System.out.println("password : " + mysqlpassword);
			System.out.println("DB for checking user");
			Class.forName(driver).newInstance();
			conn = DriverManager.getConnection(url + dbName, mysqluserName,
					mysqlpassword);
			String query = "select * from users";
			st = conn.createStatement();
			ResultSet rs = st.executeQuery(query);
			String uname = null;
			String pwd = null;
			while (rs.next()) {
				uname = rs.getString("user_id");
				System.out.println("uname:::"+uname);
				pwd = rs.getString("password");
				System.out.println("From DB uname::::"+user.getUserId());
				if (uname.equals(user.getUserId()) && pwd.equals(user.getPassword())) {
					System.out.println("Enter");
						flag=1;
						usertype=rs.getString("user_type");
						user.setUserType(usertype);
					  System.out.println("User Type::::::"+usertype);
						break;
						
				}
				else
				{
					flag=2;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		if(flag==1)
			return null;
		else
			return null;
	

	}
	
	public boolean createAdvertisements(Advertisements adv_obj) {
		// TODO Auto-generated method stub
		
		 Connection conn = null;
		 
		 try {			 
				System.out.println("create new Advertisement");
				

				 reading the properties file 
				
				 Properties prop = new Properties();
				 ClassLoader loader =Thread.currentThread().getContextClassLoader();
				 InputStream stream =loader.getResourceAsStream("props.properties");
				 prop.load(stream);
				 String server = prop.getProperty("server");
				 connection with the mysql 
				
				 String url = "jdbc:mysql://"+ server + ":3306/";
				 String dbName = prop.getProperty("database");
				 String driver = "com.mysql.jdbc.Driver";
				 String mysqluserName = prop.getProperty("username");
				 String mysqlpassword = prop.getProperty("password");

				Class.forName(driver).newInstance();
				conn = DriverManager.getConnection(url + dbName, mysqluserName,
						mysqlpassword);
				
				String insertAdv = "insert into advertisements(adv_id,adv_status,adv_title)"
						+ "values(?,?,?)";

				PreparedStatement ps = conn.prepareStatement(insertAdv);
				ps.setString(1, adv_obj.getAd_id());
				ps.setString(2, adv_obj.getAd_status());
				ps.setString(3, adv_obj.getAd_title());
				
				ps.executeUpdate();
				ps.close();
	
				Iterator<Adlets> itr = null;
				//Iterator<Adlets> itr = adv_obj.ad_list.iterator();				
				//List<Adlets> adlets_list = new ArrayList<Adlets>();
				
				String insertAdl = "insert into adlets(adv_id,adl_id,adl_type,adl_title,url,sizex,sizey,timeout)"
						+ "values(?,0,?,?,?,?,?,?)";
				
				while(itr.hasNext())
				{
					Adlets obj = itr.next();					
					System.out.println("Adlet Data Insertion");
					PreparedStatement ps1 = conn.prepareStatement(insertAdl);
					ps1.setString(1, adv_obj.getAd_id());
					ps1.setString(2, obj.getAdl_type());
					ps1.setString(3, obj.getAdl_title());
					ps1.setString(4, obj.getUrl());
					ps1.setInt(5, obj.getSizeX());
					ps1.setInt(6, obj.getSizeY());
					ps1.setInt(7, obj.getTimeout());
					ps1.executeUpdate();
					
				}
	 
			  }catch (Exception e) {
					e.printStackTrace();
					return false;
				}
			  finally {
				  try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			  }
		 
		return true;
	}
	
	public Advertisements readData(String adv_id)
	{
		Advertisements advertisement_object = new Advertisements();
		String queryAdvertisements = "select * from advertisements where adv_id like '"+adv_id+"'";
		String queryAdlets = "select * from adlets where adv_id like '"+adv_id+"'";
		List<Adlets> adlets_list = new ArrayList<Adlets>();
		try {
			
			 reading the properties file 
			
			 Properties prop = new Properties();
			 ClassLoader loader =Thread.currentThread().getContextClassLoader();
			 InputStream stream =loader.getResourceAsStream("props.properties");
			 prop.load(stream);
			 String server = prop.getProperty("server");
			 connection with the mysql 
			 Connection conn = null;
			 String url = "jdbc:mysql://"+ server + ":3306/";
			 String dbName = prop.getProperty("database");
			 String driver = "com.mysql.jdbc.Driver";
			 String mysqluserName = prop.getProperty("username");
			 String mysqlpassword = prop.getProperty("password");

			//Statement st;
			Class.forName(driver).newInstance();
			conn = DriverManager.getConnection(url + dbName, mysqluserName,mysqlpassword);
			Statement stAdv = conn.createStatement();
			Statement stAdl = conn.createStatement();
			ResultSet rsAdv = stAdv.executeQuery(queryAdvertisements);
			System.out.println("Advertisement ResultSet: "+rsAdv.toString());
			ResultSet rsAdl = stAdl.executeQuery(queryAdlets);
			System.out.println("Adlet ResultSet: "+rsAdl.toString());
			while(rsAdl.next())
			{
				Adlets adl = new Adlets();
				adl.setAdl_id(rsAdl.getString("adl_id"));
				adl.setAdl_type(rsAdl.getString("adl_type"));
				adl.setAdl_title(rsAdl.getString("adl_title"));
				adl.setUrl(rsAdl.getString("url"));
				adl.setSizeX(rsAdl.getInt("sizex"));
				adl.setSizeY(rsAdl.getInt("sizey"));
				adl.setTimeout(rsAdl.getInt("timeout"));
				adlets_list.add(adl);					
			}

			while(rsAdv.next())
			{
				advertisement_object.setAd_id(rsAdv.getString("adv_id"));
				advertisement_object.setAd_status(rsAdv.getString("adv_status"));
				advertisement_object.setAd_title(rsAdv.getString("adv_title"));
			}
			advertisement_object.setAd_list(adlets_list);
			conn.close();
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return advertisement_object;
	}
	
	private Advertisements getAdvertisement(String advertisementFilename) {
		System.out.println("method advSearch called");
		System.out.println("Search Key Advertisement ID:" + advertisementFilename);				
		String filePath = null;
		
		 //AdPortalUtils obj = new AdPortalUtils();
		filePath = AdPortalUtils.readPropertiesFile("advertisements_location");
		filePath = filePath + advertisementFilename;
	    System.out.println("file path call : " + filePath);
	
		//String filePath = "C:/Users/bgh32004/Desktop/sample training/Adportal/src/com/aricent/adportal/AdportalXmlFile.xml";
		File xmlFile = new File(filePath);
		System.out.println("xml file path" + filePath);

		if (xmlFile.exists()) {
			try {
				XMLReader reader = XMLReaderFactory.createXMLReader();
				reader.parse(filePath);
				System.out.println("Input XML file parsed via SAX Parser");
				SAXParserFactory spF = SAXParserFactory.newInstance();
				SAXParser sp = spF.newSAXParser();
				sp.parse(xmlFile, this);
				
			} catch (SAXException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ParserConfigurationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}

		}
		
		else {
			System.out.println("File not found !!!");
		}

		return searched_adv;

	}
	
	@Override
	public void characters(char[] ch, int start, int length)
			throws SAXException {
		// TODO Auto-generated method stub

		_tempVal = new String(ch,start,length);

	}

	@Override
	public void startElement(String uri, String localName, String qName,
			Attributes attributes) throws SAXException {
		
		_tempVal = "";

		if (qName.equalsIgnoreCase("Advertisement")) {
			searched_adv = new Advertisements();
			searched_adv.setAd_id(attributes.getValue("id"));
			searched_adv.setAd_status(attributes.getValue("status"));
		}

		if (qName.equalsIgnoreCase("Adlet")) {
			adlet = new Adlets();
			adlet.setAdl_id(attributes.getValue("id"));
			adlet.setAdl_type(attributes.getValue("type"));
		}

	}

	@Override
	public void endElement(String uri, String localName, String qName)
			throws SAXException {

		// TODO Auto-generated method stub

		if (qName.equalsIgnoreCase("Advertisement")) {
			//searched_adv.setAd_id(adv_id);
			searched_adv.setAd_list(adlets);
		} else if (qName.equalsIgnoreCase("Adlet")) {
			adlets.add(adlet);
			//adlet.setAdl_id(Integer.parseInt(adv_type));
		}  else if (qName.equalsIgnoreCase("TitleAdv")) {
			searched_adv.setAd_title(_tempVal);
		} else if (qName.equalsIgnoreCase("Title")) {
			adlet.setAdl_title(_tempVal);
		} else if (qName.equalsIgnoreCase("Url")) {
			adlet.setUrl(_tempVal);
		} else if (qName.equalsIgnoreCase("sizeX")) {
			adlet.setSizeX(Integer.parseInt(_tempVal));
		} else if (qName.equalsIgnoreCase("sizeY")) {
			adlet.setSizeY(Integer.parseInt(_tempVal));
		} else if (qName.equalsIgnoreCase("Timeout")) {
			adlet.setTimeout(Integer.parseInt(_tempVal));
		}
		
	}
	
	public boolean storeData(String filePath) {
		// TODO Auto-generated method stub
		DataStoreProvider obj = new DataStoreProvider();
		Advertisements advertisement_object = obj.getAdvertisement(filePath);
		String insert = "insert into advertisements(adv_id,adv_type,adv_title)"
			+ "values(?,?,?)";
		String query = "insert into adlets(adv_id,adl_id,adl_type,adl_title,url,sizex,sizey,timeout)"
			+ "values(?,?,?,?,?,?,?,?)";
		
		try {
			
			 reading the properties file 
			
			 Properties prop = new Properties();
			 ClassLoader loader =Thread.currentThread().getContextClassLoader();
			 InputStream stream =loader.getResourceAsStream("props.properties");
			 prop.load(stream);
			 String server = prop.getProperty("server");
			 connection with the mysql 
			 Connection conn = null;
			 String url = "jdbc:mysql://"+ server + ":3306/";
			 String dbName = prop.getProperty("database");
			 String driver = "com.mysql.jdbc.Driver";
			 String mysqluserName = prop.getProperty("username");
			 String mysqlpassword = prop.getProperty("password");

			//Statement st;
			Class.forName(driver).newInstance();
			conn = DriverManager.getConnection(url + dbName, mysqluserName,mysqlpassword);
			PreparedStatement ps = conn.prepareStatement(insert);
			ps.setString(1, advertisement_object.getAd_id());
			ps.setString(2, advertisement_object.getAd_status());
			ps.setString(3, advertisement_object.getAd_title());
			ps.executeUpdate();
			ps.close();
			conn.close();
			//Iterator<Adlets> itr = advertisement_object.ad_list.iterator();
			Iterator<Adlets> itr = null;
			while(itr.hasNext())
			{
				Adlets adl_obj = itr.next();
				Connection conn_adl = null; 
				conn_adl = DriverManager.getConnection(url + dbName, mysqluserName,mysqlpassword);
				PreparedStatement ps_adl = conn_adl.prepareStatement(query);
				ps_adl.setString(1, advertisement_object.getAd_id());
				ps_adl.setString(2, adl_obj.getAdl_id());
				ps_adl.setString(3, adl_obj.getAdl_type());
				ps_adl.setString(4, adl_obj.getAdl_title());
				ps_adl.setString(5, adl_obj.getUrl());
				ps_adl.setInt(6, adl_obj.getSizeX());
				ps_adl.setInt(6, adl_obj.getSizeY());
				ps_adl.setInt(6, adl_obj.getTimeout());
				ps_adl.executeUpdate();
				ps_adl.close();
				conn_adl.close();
				
				
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return false;
	}
	
}
*/