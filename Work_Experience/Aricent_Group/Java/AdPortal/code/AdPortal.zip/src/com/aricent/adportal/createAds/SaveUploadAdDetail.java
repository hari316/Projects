package com.aricent.adportal.createAds;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.aricent.adportal.datastore.hbn.Adlets;
import com.aricent.adportal.datastore.hbn.Advertisements;
import com.aricent.adportal.datastore.hbn.Users;
import com.aricent.adportal.utils.AdPortalUtils;

/**
 * Servlet implementation class SaveUploadAdDetail
 */
public class SaveUploadAdDetail extends HttpServlet {
	private static final long	serialVersionUID	= 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public SaveUploadAdDetail() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
		System.out.println("SaveUploadAdDetails Servlet:::doPost Method called ...");

		HttpSession session = request.getSession();
		String userId = session.getAttribute("userId").toString();
		File filePath;

		List<FileItem> items;
		Advertisements adObj = null;
		List<Adlets> adlets = new ArrayList<Adlets>();
		String adId = null;
		String adTitle = null;
		String status = "ADDED";
		Adlets adletObj = new Adlets();
		int counter = 1000;

		/*
		 * Properties prop = new Properties(); ClassLoader loader =
		 * Thread.currentThread().getContextClassLoader(); InputStream stream =
		 * loader.getResourceAsStream("props.properties"); prop.load(stream);
		 * StringBuilder file_loc = new
		 * StringBuilder(prop.getProperty("uploadAdv_Loc")).append(userId);
		 */

		StringBuilder file_loc = new StringBuilder(AdPortalUtils.readPropertiesFile("uploadAdv_Loc")).append(userId);
		StringBuilder Uploadfile_loc = new StringBuilder(file_loc);
		System.out.println("File Location: " + file_loc);
		try {
			ServletFileUpload servletFileUpload = new ServletFileUpload(new DiskFileItemFactory());
			items = servletFileUpload.parseRequest(request);
			for (FileItem item : items) {

				if (!item.isFormField()) {
					// <input type="file">
					System.out.println("img Field name: " + item.getFieldName());
					System.out.println("File name: " + item.getName());
					System.out.println("File size: " + item.getSize());
					System.out.println("File type: " + item.getContentType());
					if (item.getContentType().startsWith("image/")) {
						filePath = new File(getServletContext().getRealPath(file_loc.toString() + "/images"));
					} else if (item.getContentType().startsWith("video/")) {
						filePath = new File(getServletContext().getRealPath(file_loc.toString() + "/videos"));
					} else {
						filePath = new File(getServletContext().getRealPath(file_loc.toString() + "/otherFiles"));
					}
					if (item.getFieldName().equals("url")) {
						adletObj.setUrl(item.getName());
						adletObj.setAdlType(item.getContentType());

						System.out.println("File Upload Directory: " + filePath.getPath());

						if (!filePath.exists()) {
							filePath.mkdirs();
						}
						File file = new File(new StringBuilder(filePath.getPath()).append('\\').append(item.getName()).toString());
						item.write(file);
					}
				} else {
					// <input type="text|submit|hidden|password|button">,
					// <select>, <textarea>, <button>
					if (item.getFieldName().equals("title")) {
						adTitle = item.getString();
						adId = getServletContext().getAttribute("uploadAdId").toString();
						file_loc.append("/").append(adId);
						File oldFile = new File(getServletContext().getRealPath(Uploadfile_loc.toString() + "/" + userId));
						System.out.println("Old File: " + oldFile.getPath());
						if (oldFile.exists()) {
							System.out.println("Renaming of upload directory from userId to Advertisement Id ...");
							File newFile = new File(getServletContext().getRealPath(Uploadfile_loc.toString() + "/" + adId));
							oldFile.renameTo(newFile);
							//getServletContext().setAttribute("uploadAdId", adId);
						}
						Date date = new Date();
						Users user = new Users();
						user.setUserId(userId);
						adObj = new Advertisements(adId, user, status, adTitle, date.toString());
					} else if (item.getFieldName().equals("adletTitle")) {
						adletObj.setAdlTitle(item.getString());
					} else if (item.getFieldName().equals("urlText")) {
						String urlName = item.getString();
						String[] istr = urlName.split(":");
						if (urlName.startsWith("image/")) {
							adletObj.setAdlType(istr[0]);
						} else if (urlName.startsWith("video/")) {
							adletObj.setAdlType(istr[0]);
						} else {
							adletObj.setAdlType("Others/");
						}
						adletObj.setUrl(istr[1]);	
					} else if (item.getFieldName().equals("sizeX")) {
						adletObj.setSizex(Integer.parseInt(item.getString()));
					} else if (item.getFieldName().equals("sizeY")) {
						adletObj.setSizey(Integer.parseInt(item.getString()));
					} else if (item.getFieldName().equals("timeOut")) {
						adletObj.setTimeout(Integer.parseInt(item.getString()));
						adletObj.setAdlId(adId + counter++);
						adletObj.setAdvertisements(adObj);
						adlets.add(adletObj);
						adletObj = new Adlets();
					}

				}
			}
		} catch (FileUploadException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Set<Adlets> adletSet = new HashSet<Adlets>(adlets);
		adObj.setAdletses(adletSet);
		adObj.setAdvId(adId);
		System.out.println(adObj);
		System.out.println("Advertisement details saved successfully ....");
		getServletContext().setAttribute(adId, adObj);
		response.sendRedirect("PreviewAd.jsp?adId=" + adId);
	}

}
