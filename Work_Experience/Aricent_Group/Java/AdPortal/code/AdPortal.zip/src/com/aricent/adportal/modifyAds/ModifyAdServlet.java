package com.aricent.adportal.modifyAds;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.aricent.adportal.datastore.DataStore;
import com.aricent.adportal.datastore.DataStoreFactory;
import com.aricent.adportal.datastore.hbn.Adlets;
import com.aricent.adportal.datastore.hbn.Advertisements;

/**
 * Servlet implementation class ModifyAdServlet
 */
public class ModifyAdServlet extends HttpServlet {
	private static final long	serialVersionUID	= 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ModifyAdServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		/**
		 * Description: This method get the details of the particular
		 * advertisement id
		 * 
		 * @return Advertisement Object
		 */

		System.out.println("Modify Ad Servlet ::: do get Method called ....");

		Advertisements admain = null;
		List<Adlets> adlets = null;
		String adId = request.getParameter("keySearch");

		System.out.println("Advertisement Id Key Search: " + adId);

		DataStore displayAdobj = DataStoreFactory.getHiber();
		admain = displayAdobj.readData(adId);

		System.out.println("Advertisement Details after Database call....\n" + admain);
		String modifyAdObj = null;
		JSONObject Adobj = new JSONObject();
		try {

			if (null == admain) {
				Adobj.put("status", 0);
			} else {
				Adobj.put("status", 1);
				Adobj.put("advId", admain.getAdvId());
				Adobj.put("adTitle", admain.getAdvTitle());

				adlets = new ArrayList<Adlets>(admain.getAdletses());

				int adletSize = adlets.size();

				Adobj.put("adletSize", adletSize);

				JSONArray objArray = new JSONArray();
				JSONObject obj;
				for (int i = 0; i < adletSize; i++) {
					obj = new JSONObject();
					adlets.get(i).setAdlId(adlets.get(i).getAdlId().replace(admain.getAdvId(), ""));
					obj.put("adletId", adlets.get(i).getAdlId());
					obj.put("adletTitle", adlets.get(i).getAdlTitle());
					obj.put("adletType", adlets.get(i).getAdlType());
					obj.put("adletUrl", adlets.get(i).getUrl());
					obj.put("adletSX", adlets.get(i).getSizex());
					obj.put("adletSY", adlets.get(i).getSizey());
					obj.put("adletTimeout", adlets.get(i).getTimeout());
					objArray.put(obj);
				}

				Adobj.put("adlets", objArray);
			}
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println("JSON OBJECTS" + Adobj.toString());
		// getServletContext().setAttribute(modifyAdObj, Adobj);
		response.getWriter().write(Adobj.toString());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
