package com.aricent.adportal.junits;


import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.json.JSONException;
import org.json.JSONObject;

import com.aricent.adportal.datastore.hbn.Adlets;
import com.aricent.adportal.datastore.hbn.Advertisements;
import com.aricent.adportal.datastore.hbn.Users;
import com.aricent.adportal.service.ServiceProvider;

import junit.framework.TestCase;


public class ServiceProviderTest extends TestCase {

	ServiceProvider obj;
	Users userObjCreate;
	JSONObject jsonObjcreate;
	JSONObject jsonObjcheck;
	Advertisements advObj;
	Set<Adlets> adlets;
	Adlets adlObj;
	List<Advertisements> advList;
	public ServiceProviderTest() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ServiceProviderTest(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	@Override
	protected void setUp() throws Exception {
		// TODO Auto-generated method stub
		super.setUp();
		System.out.println("set up function");
		obj = new ServiceProvider();
		userObjCreate = new Users("5007","User","user5","user5","neha","surya","neha.surya@gmail.com","9876543210","chennai","tamil nadu","india",null);
		advObj = new Advertisements("advertisements", userObjCreate, "submitted", "title", "27-3-2013");		
	}
	
	@Override
	protected void tearDown() throws Exception {
		// TODO Auto-generated method stub
		super.tearDown();
		System.out.println("tear down function");
		obj = null;		
	}
	
	public void testCreateUser()
	{
		System.out.println("entered create");
		jsonObjcreate = obj.createUser(userObjCreate);
		 try {
			assertEquals(jsonObjcreate.getBoolean("issignup"), true);
			System.out.println("The Sign Up done Successfully");
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void testCheckUserAvailability()
	{
		System.out.println("entered check");
		jsonObjcheck = obj.checkUserAvailability("1001");
		 try {
			assertEquals(jsonObjcheck.getBoolean("isavailabile"), true);
			System.out.println("The User Id exist");
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public void testStoreAdvertisement()
	{
		System.out.println("store advertisement function");
		assertEquals(obj.storeAdvertisement(advObj), true);
	}
	
	public void testGetAdvertisements()
	{		
		//assertEquals(obj.getAdvertisements(), true);
		System.out.println("get advertisements list");
		System.out.println(obj.getAdvertisements().size());
		assertNotNull(obj.getAdvertisements());
	}
	
	/*public void testCreateOrUpdateAdvertisements()
	{		
		assertEquals(obj.createOrUpdateAdvertisements(advObj), true);
	}
	*/
	
/*	
	public void testgetAdvertisementDetails() {
		try {
			ServiceProvider provider = new ServiceProvider();
			Advertisements adv = provider.getAdvertisement("AD_7312_TVS");
			assertEquals("Failed to get valid advertisement details ..","AD_7312_TVS", adv.getAdvId());
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
	}
	*/
	
	
	
	/*public void testStoreAdlets()
	{
		System.out.println("store advertisement function");
		assertEquals(obj.storeAdlets(adlets), true);
		
	}
	*/
	
	
}
