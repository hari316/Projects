package com.aricent.adportal.loginusers;

import java.io.IOException;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import com.aricent.adportal.datastore.DataStore;
import com.aricent.adportal.datastore.DataStoreFactory;
import com.aricent.adportal.datastore.hbn.Advertisements;
import com.aricent.adportal.datastore.hbn.Users;
import com.aricent.adportal.service.ServiceProvider;

/**
 * Servlet implementation class SignUpServlet
 */
public class SignUpServlet extends HttpServlet {
	private static final long	serialVersionUID	= 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public SignUpServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		/**
		 * Description: This method checks if the userid is already exist or not
		 * in the database. If not it create new user otherwise give the message
		 * "The User Id already Exist"
		 * 
		 * @return JSON Object
		 */

		String userid = (String) request.getParameter("userId");
		String usertype = (String) request.getParameter("userType");
		String password = (String) request.getParameter("password");
		String confirmPassword = (String) request.getParameter("confirmPassword");
		String firstName = (String) request.getParameter("firstName");
		String lastName = (String) request.getParameter("lastName");
		String emailId = (String) request.getParameter("emailId");
		String contactNo = (String) request.getParameter("contactNo");
		String address = (String) request.getParameter("address");
		String state = (String) request.getParameter("state");
		String country = (String) request.getParameter("country");
		try {

			// Login obj = new Login();
			DataStore obj = DataStoreFactory.getHiber();
			ServiceProvider provider = new ServiceProvider();

			if ("validate".equals(request.getParameter("requestType"))) {
				System.out.println("call function validate");
				JSONObject jsonObj = provider.checkUserAvailability(userid);
				System.out.println("servlet : " + jsonObj.toString());
				response.getWriter().write(jsonObj.toString());
			}

			if ("signup".equals(request.getParameter("requestType"))) {
				System.out.println("call function signup");
				/*
				 * Users user = new Users(userid, usertype, password,
				 * confirmPassword, firstName, lastName, emailId, contactNo,
				 * address, state, country);
				 */
				// Set<Advertisements> adv_set = null;
				Users user = new Users();
				user.setUserId(userid);
				user.setUserType(usertype);
				user.setPassword(password);
				user.setConfirmPassword(confirmPassword);
				user.setFirstname(firstName);
				user.setLastname(lastName);
				user.setEmailId(emailId);
				user.setContactNumber(contactNo);
				user.setAddress(address);
				user.setState(state);
				user.setCountry(country);
				// user.setAdvertisementses(adv_set);
				JSONObject jsonObj = provider.createUser(user);
				response.getWriter().write(jsonObj.toString());
			}

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

	}

}
