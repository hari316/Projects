package com.aricent.adportal.loginusers;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONObject;

import com.aricent.adportal.datastore.DataStore;
import com.aricent.adportal.datastore.DataStoreFactory;
import com.aricent.adportal.datastore.hbn.Users;
import com.aricent.adportal.service.ServiceProvider;

/**
 * Servlet implementation class CheckUserServlet
 */
public class CheckUserServlet extends HttpServlet {
	private static final long	serialVersionUID	= 1L;

	/**
	 * Default constructor.
	 */
	public CheckUserServlet() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		/**
		 * Description: This method mapping with key value pair of json and
		 * provide message as per condition get true.
		 * 
		 * @return JSON Object
		 */
		String userName = request.getParameter("username");
		String password = request.getParameter("password");
		try {
			// Login obj = new Login();
			// DataStore obj = DataStoreFactory.getData();
			ServiceProvider provider = new ServiceProvider();
			JSONObject statusObj = provider.checkUser(userName, password);
			System.out.println("Status : " + statusObj.getBoolean("isValidUser"));
			if (!statusObj.getBoolean("isValidUser")) {
				System.out.println("not valid user");
				response.sendRedirect("login.jsp?msg=Invalid Username or Password");
			} else {
				HttpSession session = request.getSession();
				session.setAttribute("userId", userName);
				session.setAttribute("loginUser", userName);
				if (statusObj.getBoolean("isTypeUser")) {
					System.out.println("User authentication successfull");
					response.sendRedirect("userhome.jsp");
				} else {
					System.out.println("Admin authentication successfull");
					response.sendRedirect("AdminMenu.jsp");
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

	}

}
