package com.aricent.adportal.displayAds;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONException;
import org.json.JSONObject;

import com.aricent.adportal.datastore.DataStore;
import com.aricent.adportal.datastore.DataStoreFactory;
import com.aricent.adportal.datastore.hbn.Adlets;
import com.aricent.adportal.datastore.hbn.Advertisements;
import com.aricent.adportal.utils.AdPortalUtils;

/**
 * Servlet implementation class DisplayAdServlet
 */
public class DisplayAdServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Advertisements admain = null;
	List<Adlets> temp = null;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public DisplayAdServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		System.out.println("DisplayAdServlet::: doGet Method Called....");
		String adId = request.getParameter("adId");
		String index = request.getParameter("index");
		String flag = request.getParameter("flagkey");

		if (AdPortalUtils.isNullOrEmpty(adId)) {
			adId = "AD76937";
		}

		if (flag.equals("1")) {
			DataStore displayAdobj = DataStoreFactory.getHiber();
			admain = displayAdobj.readData(adId);
			
		}
		
		if (null == admain) {
				System.out.println("No records found .....");
				JSONObject obj = new JSONObject();
				try {
					obj.put("advnull",
							"No records found... Please submit the advertisement...");
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				response.getWriter().write(obj.toString());
			} else {
				System.out.println("Advertisement Details after Database call....\n"
						+ admain);			
				temp = new ArrayList<Adlets>(admain.getAdletses());
				if ("Approved".equals(admain.getAdvStatus())) {
					System.out.println("approved check");
					int count = 0;
					int total = 0;

					Iterator<Adlets> i = temp.iterator();

					int ind = Integer.parseInt(index);

					total = temp.size();

					while (i.hasNext()) {
						Adlets a = (Adlets) i.next();
						if (count == ind) {
							JSONObject obj = new JSONObject();
							// System.out.println("Image URL: "+a.getUrl());
							try {
								obj.put("userId", admain.getUsers().getUserId());
								obj.put("advId", admain.getAdvId());
								obj.put("advTitle", admain.getAdvTitle());
								obj.put("title", a.getAdlTitle());
								obj.put("url", a.getUrl());
								obj.put("adletId", a.getAdlId());
								obj.put("sizeX", a.getSizex());
								obj.put("sizeY", a.getSizey());
								obj.put("timeOut", a.getTimeout());
								obj.put("type", a.getAdlType());

								if (a.getAdlType().startsWith("image/")) {
									obj.put("tagType", "img");
								} else if (a.getAdlType().startsWith("video/")) {
									obj.put("tagType", "video");
								} else {
									obj.put("tagType", "other");
								}

								if ((count + 1) == total) {
									obj.put("hasMore", "No");
								} else {
									obj.put("hasMore", "Yes");
								}
							} catch (Exception ex) {
								ex.printStackTrace();
							}
							response.getWriter().write(obj.toString());
						}
						count++;
					}

				} else {
					System.out.println("Advertisement not approved .....");
					JSONObject obj = new JSONObject();
					try {
						obj.put("notapproved",
								"The Admin has not yet approved the Advertisement");
					} catch (JSONException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					response.getWriter().write(obj.toString());

				}
			}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
