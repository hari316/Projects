package com.aricent.adportal.datastore;

import java.util.List;
import java.util.Set;

import com.aricent.adportal.datastore.hbn.Adlets;
import com.aricent.adportal.datastore.hbn.Advertisements;
import com.aricent.adportal.datastore.hbn.Users;

public interface DataStore {

	public List<Users> ValidateUser(Users user);
	public boolean createNewUser(Users obj);
	public Advertisements readData(String adv_id);
	public boolean updateAdvertisements(Advertisements adv_obj);
	public boolean createAdvertisements(Advertisements adv_obj);
	public boolean adAdlets(Set<Adlets> adlets);
	public List<Advertisements> getAdvertisements();
	public List<Users> CheckUser(Users user);
	public List<Advertisements> getUsersAdvertisements(String userId);
}
