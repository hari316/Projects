package com.aricent.adportal.service;

import java.util.List;
import java.util.Set;
import org.json.JSONObject;
import com.aricent.adportal.datastore.DataStore;
import com.aricent.adportal.datastore.DataStoreFactory;
import com.aricent.adportal.datastore.hbn.Adlets;
import com.aricent.adportal.datastore.hbn.Advertisements;
import com.aricent.adportal.datastore.hbn.Users;


/**
 * @author BGH29309
 *
 */

public class ServiceProvider {

/**
 * Description: This method checks if user is valid or Not.
 * 
 * @param userName
 * @param password
 * @return JSON Object
 */
	public JSONObject checkUser(String userName, String password) {
		
		System.out.println("ServiceProvider:::checkUser Method Called ... ");
		System.out.println("Input paramter User Name: "+userName);
		
		List<Users> satusList = null;
		JSONObject jsonObj = new JSONObject();
		try {

			DataStore obj = DataStoreFactory.getHiber();
			Users user = new Users();
			user.setUserId(userName);
			user.setPassword(password);
			satusList = obj.ValidateUser(user);
			if (satusList == null || satusList.size() == 0) {
				System.out.println("not valid user");
				jsonObj.put("isValidUser", false);
			} else {
				jsonObj.put("isValidUser", true);
				for (Users userobj : satusList) {
					if ("User".equals(userobj.getUserType())) {
						jsonObj.put("isTypeUser", true);
					} else {
						jsonObj.put("isTypeUser", false);
					}
				}
			}

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return jsonObj;
	}

	/**
	 * Description: This method creates a new user account.
	 * 
	 * @param user_obj
	 * @return JSON Object
	 */
	public JSONObject createUser(Users user_obj) {

		System.out.println("ServiceProvider:::createUser Method Called ... ");
		System.out.println("Input paramter User Object: "+user_obj.getUserId());
		
		DataStore obj = DataStoreFactory.getHiber();
		JSONObject jsonObj = new JSONObject();
		try {
			if (obj.createNewUser(user_obj)) {
				jsonObj.put("issignup", "true");
			} else {
				jsonObj.put("issignup", "false");
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return jsonObj;
	}

	
	/**
	 * Description: This method checks if selected user Id is available(unique) or Not.
	 * 
	 * @param user_id
	 * @return JSON Object
	 */
	public JSONObject checkUserAvailability(String user_id) {
		
		System.out.println("ServiceProvider:::checkUserAvailability Method Called ... ");
		System.out.println("Input paramter User ID: "+user_id);
		
		List<Users> usersList = null;
		DataStore obj = DataStoreFactory.getHiber();
		Users user = new Users();
		user.setUserId(user_id);
		JSONObject jsonObj = new JSONObject();
		try {
			usersList = obj.CheckUser(user);
			if (usersList == null) {
				System.out.println("no users");
				jsonObj.put("isavailabile", false);
			} else {
				System.out.println("users available");
				jsonObj.put("isavailabile", false);
				for (Users userobj : usersList) {
					if (user_id.equals(userobj.getUserId())) {
						jsonObj.put("isavailabile", true);
						System.out.println("the user exist");
					}
				}
			}

		} catch (Exception e) {
			// TODO: handle exception
		}

		return jsonObj;
	}

	/**
	 * Description: This method stores advertisement details in database.
	 * 
	 * @param adv
	 * @return flag
	 */
	public boolean storeAdvertisement(Advertisements adv) {
		
		System.out.println("ServiceProvider:::storeAdvertisement Method Called ... ");
		System.out.println("Input paramter Adv ID: "+adv.getAdvId());
		
		DataStore obj = DataStoreFactory.getHiber();
		boolean flag = obj.createAdvertisements(adv);
		return flag;
	}

	
	/**
	 * Description: This method stores adlet details in database.
	 * 
	 * @param adlets
	 * @return flag
	 */
	public boolean storeAdlets(Set<Adlets> adlets) {
		
		System.out.println("ServiceProvider:::storeAdlets Method Called ... ");
		System.out.println("Input paramter Adlets Size: "+adlets.size());
		
		DataStore obj = DataStoreFactory.getHiber();
		boolean flag = obj.adAdlets(adlets);
		return flag;
	}

	/**
	 * Description: This method returns list of all advertisement details from database.
	 * 
	 * @return List<Advertisements>
	 */
	public List<Advertisements> getAdvertisements() {
		
		System.out.println("ServiceProvider:::getAdvertisements Method Called ... ");
		
		DataStore obj = DataStoreFactory.getHiber();
		List<Advertisements> admindata = obj.getAdvertisements();
		return admindata;
	}
	

	/**
	 * Description: This method returns advertisement details from database based on Adv ID.
	 * 
	 * @param advId
	 * @return Advertisements
	 */
	public Advertisements getAdvertisement(String advId) {

		System.out.println("ServiceProvider:::getAdvertisement Method Called ... ");
		System.out.println("Input paramter Adv ID: "+advId);
		
		DataStore obj = DataStoreFactory.getHiber();
		Advertisements result = obj.readData(advId);
		return result;
	}

	/**
	 * Description: This method returns list of all advertisement details from database based on User ID.
	 * 
	 * @param userId
	 * @return List<Advertisements>
	 */
	public List<Advertisements> getUserAdvertisements(String userId) {
		
		System.out.println("ServiceProvider:::getUserAdvertisements Method Called ... ");
		System.out.println("Input paramter User ID: "+userId);
		
		DataStore obj = DataStoreFactory.getHiber();
		List<Advertisements> userAdv = obj.getUsersAdvertisements(userId);
		return userAdv;
	}

	/**
	 * Description: This method creates or updates advertisement details into database.
	 * 
	 * @param adv
	 * @return flag
	 */
	public boolean createOrUpdateAdvertisements(Advertisements adv) {
		
		System.out.println("ServiceProvider:::createOrUpdateAdvertisements Method Called ... ");
		System.out.println("Input paramter Adv ID: "+adv.getAdvId());
		
		DataStore obj = DataStoreFactory.getHiber();
		boolean flag = obj.createAdvertisements(adv);
		return flag;
	}
	
	/**
	 * Description: This method creates or updates advertisement details into database.
	 * 
	 * @param adv
	 * @return flag
	 */
	public boolean updateAdvertisementsStatus(Advertisements adv) {
		
		System.out.println("ServiceProvider:::updateAdvertisements Method Called ... ");
		System.out.println("Input paramter Adv ID: "+adv.getAdvId());
		
		DataStore obj = DataStoreFactory.getHiber();
		boolean flag = obj.updateAdvertisements(adv);
		return flag;
	}

	/*
	 * public static void main(String[] args) {
	 * 
	 * DataStore displayAdobj = DataStoreFactory.getHiber();
	 * 
	 * --------- Store Advertisements Details ----------
	 * 
	 * Advertisements adv = new Advertisements(); Set adletSet = new HashSet();
	 * Adlets adlet = new Adlets(); adlet.setAdlId("789");
	 * adlet.setAdlTitle("testadlet"); adletSet.add(adlet);
	 * 
	 * adv.setAdvId("123"); Users user = new Users(); user.setUserId("29309");
	 * adv.setUsers(user); ServiceProvider provider = new ServiceProvider();
	 * provider.storeAdvertisement(adv);
	 * 
	 * provider.storeAdlets(adletSet);
	 * 
	 * 
	 * ------ Retrieve Advertisements Details ----------
	 * 
	 * ServiceProvider provider = new ServiceProvider(); Advertisements adv =
	 * provider.getAdvertisement("AD_7312_TVS");
	 * System.out.println("AD Details :::"); System.out.println(adv);
	 * 
	 * }
	 */
}
