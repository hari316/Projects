/**
 * 
 */

function loginformValidation()  
{  
	var uname = document.loginform.username; 
	var pwd = document.loginform.password;

	if(username_validation(uname))  
	{  
		if(password_validation(pwd))  
		{  		
			document.forms.loginform.submit();
			
			/*		
			$.getJSON('CheckUserServlet',{requestType:'validate',uname:uname,pwd:pwd}, function(data)
			    	{	
						//alert(data.isavailabile);
						if(data.isvalid)
						{
							alert("Valid User");
						}
						else
						{
							alert("Not Valid User");
						}						
			    	});			    	
			 */
			
		}
	}
	return false;  
}

function username_validation(uname)  
{  
	var uname_len = uname.value.length;  
	if (uname_len == 0 )  
	{  
		alert("User Name should not be empty");
		uname.focus();  
		return false;  
	}  
	return true;  
}  

function password_validation(pwd)  
{  
	var pwd_len = pwd.value.length;  
	if (pwd_len == 0 )  
	{  
		alert("Password should not be empty");
		pwd.focus();  
		return false;  
	}  
return true;  
}  




