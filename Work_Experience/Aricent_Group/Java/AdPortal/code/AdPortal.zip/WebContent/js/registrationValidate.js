
function registrationformValidation()  
{  
	var uid = document.checkform.userId; 
	var utype = document.registrationform.userType;
	var pwd = document.registrationform.password; 
	var confpwd = document.registrationform.confirmPassword;  
	var fname = document.registrationform.firstName;  
	var lname = document.registrationform.lastName;  
	var email = document.registrationform.emailId;  
	var contno = document.registrationform.contactNo;  
	var addr = document.registrationform.address;
	var st = document.registrationform.state;
	var coun = document.registrationform.country;
	
	if(password_validation(pwd))  {  
		if(confirmpassword_validation(pwd,confpwd))  {   
			$.getJSON('SignUpServlet',{requestType:'signup',userId : uid.value,userType : utype.value,password : pwd.value,confirmPassword : confpwd.value,firstName : fname.value,lastName : lname.value,emailId : email.value,contactNo : contno.value,address : addr.value,state : st.value,country : coun.value}, function(data)
			{	
				if(data.issignup)
				{
					alert("Registered Successfully. Now Login with the New User Name and Password");
					document.location.href="login.jsp";
					
				}
				else
				{
					alert("Registration Unsuccessful");
				}						
			});		
		}
	}
	
	
	/*
	if(userid_validation(uid))  {  
		if(usertype_validation(utype))  {  
			if(password_validation(pwd))  {  
				if(confirmpassword_validation(pwd,confpwd))  {   
					if(firstname_validation(fname))  {  
						if(lastname_validation(lname))  {  
							if(email_validation(email))  {  
								if(contactnumber_validation(contno))  {  
									if(address_validation(addr))  { 
										if(state_validation(st))  { 
											if(country_validation(coun))  { 
												
												$.getJSON('SignUpServlet',{requestType:'signup',userId : uid.value,userType : utype.value,password : pwd.value,confirmPassword : confpwd.value,firstName : fname.value,lastName : lname.value,emailId : email.value,contactNo : contno.value,address : addr.value,state : st.value,country : coun.value}, function(data)
												    	{	
														
															if(data.issignup)
															{
																alert("Registered Successfully. Now Login with the New User Name and Password");
																document.forms[0].submit();
																
															}
															else
															{
																alert("Registration Unsuccessful");
															}						
												    	});			    	
												 
											}
										}
									}
								}  
							}   
						}  
					}   
				}  
			}  
		}  
	}  */
	
	return false;  
}

function userid_validation(uid)  
{  
	var uid_len = uid.value.length;  
	if (uid_len == 0 )  
	{  
		alert("User Id should not be empty");
		uid.focus();  
		return false;  
	}  
	return true;  
}  


function usertype_validation(utype)  
{  
	var utype_len = utype.value.length;  
	if (utype_len == 0 )  
	{  
		alert("User Type should not be empty");
		uid.focus();  
		return false;  
	}  
	return true;  
}  


function password_validation(pwd)  
{  
	var letters = /^[0-9a-zA-Z]+$/;  
	var pwd_len = pwd.value.length;  
	
		if(pwd.value.match(letters))  
		{  
			return true;  
		}  
		else  
		{  
			alert('Password must have alphanumeric characters only');  
			pwd.focus();  
			return false;  
		}  
	
}  


function confirmpassword_validation(pwd,confpwd)  
{  
	var confpwd_len = confpwd.value.length;  
	if (document.registrationform.password.value != document.registrationform.confirmPassword.value)
	{
		alert("Confirm Password should be same as the Password");  
		confpwd.focus();  
		return false;	
	}
	else
	{
		return true;  
	}
}  


function firstname_validation(fname)  
{  
	var fname_len = fname.value.length;  
	if (fname_len == 0 )  
	{  
		alert("First Name should not be empty");  
		fname.focus();  
		return false;  
	}  
	return true;  
}  


function lastname_validation(lname)  
{  
	var lname_len = lname.value.length;  
	if (lname_len == 0 )  
	{  
		alert("Last Name should not be empty");  
		lname.focus();  
		return false;  
	}  
	return true;  
}  


function email_validation(email)  
{  
	var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;  
	if(email.value.match(mailformat))  
	{  
		return true;  
	}  
	else  
	{  
		alert("Emailid not valid");  
		email.focus();  
		return false;  
	}  
}


function contactnumber_validation(contno)  
{   
	var numbers = /^[0-9]+$/;  
	if(contno.value.match(numbers))  
	{  
		return true;  
	}  
	else  
	{  
		alert('Contact Number must have numeric characters only');  
		contno.focus();  
		return false;  
	}  
}  



function address_validation(addr)  
{  
	var addr_len = addr.value.length;  
	if (addr_len == 0 )  
	{  
		alert("Address should not be empty");  
		addr.focus();  
		return false;  
	}  
	return true;  
}  



function state_validation(st)  
{  
	var st_len = st.value.length;  
	if (st_len == 0 )  
	{  
		alert("State should not be empty");  
		st.focus();  
		return false;  
	}  
	return true;  
}  



function country_validation(coun)  
{  
	var coun_len = coun.value.length;  
	if (coun_len == 0 )  
	{  
		alert("Country should not be empty");  
		coun.focus();  
		return false;  
	}  
	return true;  
}  

function checkAvailability() {
	//alert("check function");
		var userId = document.getElementById("userId").value;
		//alert(userId);
			$.getJSON('SignUpServlet', {
				requestType : 'validate',
				userId : userId
			}, function(data) {
				//alert(data.isavailabile);
				if (data.isavailabile) {
					alert("The UserId already exists");
				} else {
					$("#registrationform").show();
				}

			});

}




