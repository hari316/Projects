package com.aricent.smartclient.jaxb;


import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.Validator;

import org.xml.sax.InputSource;

public class SCJAXBParser {
	
	private static JAXBContext jc = null;
	
	/**
	 * 
	 * @param xml
	 * @return
	 * @throws MUSECommonException
	 */
	public static Object unmarshalFromString(String xml) {
		return unmarshalFromString(xml, false);
	}

    /**
     * Unmarshal string containing XML file and returns constructed object.
     *
     * @param xml String
     * @return Object
     * @throws Exception
     */
    public static Object unmarshalFromString(String xml, boolean doValidation) {
        Object obj = null;
        Reader inputReader = null;
        try{
	        inputReader = new StringReader(xml);
	        obj = unmarshalFromReader(inputReader,doValidation);
	        
        } finally{
        	if(inputReader != null){
        		try {
					inputReader.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
        	}
        }

        return obj;

    }

    

    /**
     * 
     * @param input_stream
     * @return
     * @throws MUSECommonException
     */
    public static Object unmarshalFromReader(Reader inputReader) {
    	return unmarshalFromReader(inputReader,false);
    }

    /**
     * Unmarshal object from an InputStream .
     *
     * @param input_stream InputStream
     * @param doValidation 
     * @return Object
     */
    private static Object unmarshalFromReader(Reader inputReader, boolean doValidation) {
        Object obj = null;
        if(inputReader == null) {
        	return null;
        }
    	Reader buffReader = null;
        try {
        	if(inputReader instanceof BufferedReader) {
        		buffReader = inputReader;
        	}
        	else {
        		buffReader = new BufferedReader(inputReader);
        	}
            Unmarshaller u = getUnMarshaller();
        	obj = u.unmarshal(new InputSource(buffReader));
            
            if(doValidation){
            	doValidation(obj);
            }

        } catch (JAXBException je) {
        	je.printStackTrace();
        }
        finally {
        	if(!buffReader.equals(inputReader)) {
        		try {
					buffReader.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
        	}
        }
        return obj;
    }
    
    
    
    /**
     * 
     * @return
     * @throws JAXBException
     */
    private static Unmarshaller getUnMarshaller() throws JAXBException {
    	initJaxBContext();
    	Unmarshaller u  = jc.createUnmarshaller();
    	return u;
    }

    /**
     * 
     * @param obj
     * @return
     * @throws MUSECommonException
     */
    public static String marshalToString(Object obj) {
    	return marshalToString(obj, false);
    }
    /**
     * This method does marshalling of Object to String.
     *
     * @param obj Object
     * @return String
     * @throws Exception
     */
    public static String marshalToString(Object obj, boolean doValidation) {
        String xmlOutput = null;
        BufferedWriter buffWriter = null;
        try {
        	if(doValidation){
        		doValidation(obj);
        	}
        	
            Marshaller m = getMarshaller();
            m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
            StringWriter stringWriter = new StringWriter();
            buffWriter = new BufferedWriter(stringWriter);
            m.marshal(obj, buffWriter);
            xmlOutput = stringWriter.toString();
        } catch (JAXBException je) {
        	je.printStackTrace();
        } finally{
        	if(buffWriter != null) {
        		try {
					buffWriter.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
        	}
        } 
        return xmlOutput;
    }

    /**
     * 
     * @return
     * @throws JAXBException
     */
    private static Marshaller getMarshaller() throws JAXBException {
        initJaxBContext();
        Marshaller m = jc.createMarshaller();
//        m.setProperty("jaxb.encoding", "ISO-8859-1");
        return m;
    }

    
    
    /**
     * This method will validate restriction mentioned in XSD like length, pattern etc.
     * @param obj
     * @param obj2 
     * @throws JAXBException
     */
    public static void doValidation(Object obj) throws JAXBException{
    	initJaxBContext();
    	Validator v = jc.createValidator();
    	v.validate(obj);
    }

    /**
     * 
     * @throws JAXBException
     */
    private static void initJaxBContext() throws JAXBException {
    	if(jc == null){
    		synchronized(SCJAXBParser.class){
    			if(jc == null){
			        jc = JAXBContext.newInstance("com.aricent.smartclient.jaxb:");
    			}
    		}
    	}
    }
}

