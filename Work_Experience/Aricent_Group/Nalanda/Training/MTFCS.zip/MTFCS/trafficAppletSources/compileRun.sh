#!/bin/bash

echo "removing all class files"
rm target/MicroSim*.class target/de/trafficsimulation/*.class
echo "compiling with ant"
if ant; 
  then run.sh;
  else echo "Compiling failed!";
fi