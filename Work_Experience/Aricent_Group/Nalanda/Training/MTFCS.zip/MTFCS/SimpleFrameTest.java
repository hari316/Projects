import java.awt.Graphics;
import java.awt.*;
import javax.swing.*;


public class SimpleFrameTest
{
	public static void main(String[] args)
	{
		EventQueue.invokeLater(new Runnable()
		{
	public void run()
	{
		SimpleFrame frame =new SimpleFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
	});
}
}

class SimpleFrame extends JFrame
{
	public SimpleFrame()
	{
		setTitle("MULTI LANE TRAFFIC CONTROL SYSTEM");
		setSize(DEFAULT_WIDTH,DEFAULT_HEIGHT);
		//add panel to frame
		SimpleComponent component = new SimpleComponent();
		add(component);
	
	}

public static final int DEFAULT_WIDTH = 800;
public static final int DEFAULT_HEIGHT = 800;

}
class SimpleComponent extends JComponent
{
	public void paintComponent(Graphics g)
	{
		g.setColor(Color.gray);
		
		g.drawString("LANE 1 --->",100,340);
		g.drawString("LANE 1 --->",625,340);
		g.drawString("LANE 2 --->",100,390);
		g.drawString("LANE 2 --->",625,390);
		g.drawString("<--- LANE 3",100,440);
		g.drawString("<--- LANE 4",100,490);
		g.drawString("<--- LANE 3",625,440);
		g.drawString("<--- LANE 4",625,490);
		
		//change needed
		/*g.drawString("LANE 1 --->",490,100);
		g.drawString("LANE 1 --->",625,340);
		g.drawString("LANE 2 --->",100,390);
		g.drawString("LANE 2 --->",625,390);
		g.drawString("<--- LANE 3",100,440);
		g.drawString("<--- LANE 4",100,490);
		g.drawString("<--- LANE 3",625,440);
		g.drawString("<--- LANE 4",625,490);*/
		g.setColor(Color.red);
		g.fillOval(525,50,20,20);
		g.drawOval(525,50,20,20);
		
		
		g.setColor(Color.green);
		g.fillOval(525,80,20,20);
		g.drawOval(525,80,20,20);
		
		
		g.setColor(Color.yellow);
		g.fillOval(525,110,20,20);
		g.drawOval(525,110,20,20);
		g.setColor(Color.blue);
		g.drawString("RED LIGHT",570,70);
		g.drawString("GREEN LIGHT",570,100);
		g.drawString("YELLOW LIGHT",570,130);
		g.setColor(Color.blue);
		
		g.drawString("FOUR WAY NODE",70,100);
		g.drawString("VEHICLE", 125,150);
		g.setColor(Color.red);
		g.drawRect(70,130,50,20);
		g.fillRect(70,130,50,20);
		Font f;
		f = new Font("Dialog",Font.ITALIC,25); 
		setFont(f);
		
		
		//for the path A
		g.setColor(Color.black);
		g.drawLine(300,0,300,300);
		g.setColor(Color.green);
		g.drawLine(350,0,350,300);
		g.drawLine(450,0,450,300);
		g.setColor(Color.blue);
		g.drawLine(400,0,400,300);
		g.setColor(Color.black);
		g.drawLine(500,0,500,300);
		//FOR DRAWING THE BLOCKS PATH A //12 BLOCKS
		g.setColor(Color.lightGray);
		
		g.drawLine(300,0,500,0);
		g.drawLine(300,25,500,25);
		g.drawLine(300,50,500,50);
		g.drawLine(300,75,500,75);
		g.drawLine(300,100,500,100);
		g.drawLine(300,125,500,125);
		g.drawLine(300,150,500,150);
		g.drawLine(300,175,500,175);
		g.drawLine(300,200,500,200);
		g.drawLine(300,225,500,225);
		g.drawLine(300,250,500,250);
		g.drawLine(300,275,500,275);
		g.drawLine(300,300,500,300);
		//FOR DRAWING THE BLOCKS path B  //12 blocks
		g.setColor(Color.lightGray);
		g.drawLine(0,300,0,500);
		g.drawLine(25,300,25,500);
		g.drawLine(50,300,50,500);
		g.drawLine(75,300,75,500);
		g.drawLine(100,300,100,500);
		g.drawLine(125,300,125,500);
		g.drawLine(150,300,150,500);
		g.drawLine(175,300,175,500);
		g.drawLine(200,300,200,500);
		g.drawLine(225,300,225,500);
		g.drawLine(250,300,250,500);
		g.drawLine(275,300,275,500);
		g.drawLine(300,300,300,500);
		
		
		g.setColor(Color.black);
		
		// FOR THE PATH B
		g.drawLine(0,300,300,300);
		g.drawLine(0,500,300,500);
		g.setColor(Color.green);
		g.drawLine(0,350,300,350);
		g.drawLine(0,450,300,450);
		g.setColor(Color.blue);
		g.drawLine(0,400,300,400);
		
		
		//FOR DRAWING THE BLOCKS FOR PATH C
		g.setColor(Color.lightGray);
		g.drawLine(500,300,500,500);
		g.drawLine(525,300,525,500);
		g.drawLine(550,300,550,500);
		g.drawLine(575,300,575,500);
		g.drawLine(600,300,600,500);
		g.drawLine(625,300,625,500);
		g.drawLine(650,300,650,500);
		g.drawLine(675,300,675,500);
		g.drawLine(700,300,700,500);
		g.drawLine(725,300,725,500);
		g.drawLine(750,300,750,500);
		g.drawLine(775,300,775,500);
		g.drawLine(800,300,800,500);
		
		
		//FOR THE PATH C
		g.setColor(Color.black);
		g.drawLine(500,300,800,300);
		g.drawLine(500,500,800,500);
		g.setColor(Color.green);
		g.drawLine(500,350,800,350);
		g.drawLine(500,450,800,450);
		g.setColor(Color.blue);
		g.drawLine(500,400,800,400);
		
		
		//FOR DRAWING THE BLOCKS FOR PATH D
		g.setColor(Color.lightGray);
		g.drawLine(300,500,500,500);
		g.drawLine(300,525,500,525);
		g.drawLine(300,550,500,550);
		g.drawLine(300,575,500,575);
		g.drawLine(300,600,500,600);
		g.drawLine(300,625,500,625);
		g.drawLine(300,650,500,650);
		g.drawLine(300,675,500,675);
		g.drawLine(300,700,500,700);
		g.drawLine(300,725,500,725);
		g.drawLine(300,750,500,750);
		g.drawLine(300,775,500,775);
		g.drawLine(300,800,500,800);
		
		
		//FOR THE PATH D
		g.setColor(Color.black);
		g.drawLine(500,500,500,800);
		g.drawLine(300,500,300,800);
		g.setColor(Color.green);
		g.drawLine(350,500,350,800);
		g.drawLine(450,500,450,800);
		g.setColor(Color.blue);
		g.drawLine(400,500,400,800);
		
		//for drawing the lights //red/green/yellow
		g.setColor(Color.magenta);
		g.fillOval(350,350,110,110);
		
		g.drawOval(350,350,110,110);
		
		//for path B
		g.setColor(Color.red);
		g.fillOval(315,360,30,30);
		g.drawOval(315,360,30,30);
		
		g.setColor(Color.green);
		g.fillOval(315,395,30,30);
		g.drawOval(315,395,30,30);
		g.setColor(Color.yellow);
		g.fillOval(315,430,30,30);
		g.drawOval(315,430,30,30);
		
		//for path A
		g.setColor(Color.red);
		g.fillOval(350,315,30,30);
		g.drawOval(350,315,30,30);
		g.setColor(Color.green);
		g.fillOval(385,315,30,30);
		g.drawOval(385,315,30,30);
		g.setColor(Color.yellow);
		g.fillOval(420,315,30,30);
		g.drawOval(420,315,30,30);
		
		//for path C
		g.setColor(Color.red);
		g.fillOval(465,360,30,30);
		g.drawOval(465,360,30,30);
		g.setColor(Color.green);
		g.fillOval(465,395,30,30);
		g.drawOval(465,395,30,30);
		g.setColor(Color.yellow);
		g.fillOval(465,430,30,30);
		g.drawOval(465,430,30,30);
		
		//for PATH D
		g.setColor(Color.red);
		g.fillOval(350,465,30,30);
		g.drawOval(350,465,30,30);
		g.setColor(Color.green);
		g.fillOval(385,465,30,30);
		g.drawOval(385,465,30,30);
		g.setColor(Color.yellow);
		g.fillOval(420,465,30,30);
		g.drawOval(420,465,30,30);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
}